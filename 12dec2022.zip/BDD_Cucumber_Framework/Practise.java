package BDD_Cucumber.BDD_Cucumber_Framework;

public class Practise {

	public static void main(String[] args) {

		for (int i = 1; i < 5; i++) {

		if(i==3)
		{
			
			//break;
		continue;
		
		}
		System.out.println(i);
		}
		
		
		//output :  1 , 2
		
		//output :	1,2,4

		
	}

}