package BDD_Cucumber.BDD_Cucumber_Framework;

public class Example {

	Object q3;
	
	public static void main(String[] args) {
		

		
		Object q="suresh";
		Object q1=123;
		Object q2=true;
		Example d=new Example();
		System.out.println(d.q3);
	int a=10;  // int to string
	
	String z = String.valueOf(a);

	
	System.out.println(z+1);
	System.out.println(++a);
	

	
	}
}
