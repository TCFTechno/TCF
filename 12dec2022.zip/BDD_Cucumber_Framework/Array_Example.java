package BDD_Cucumber.BDD_Cucumber_Framework;

public class Array_Example {

	public static void main(String[] args) {
		
	int af=20;
	
	int age[]= {12,13,40,23,60};  // 0 to n-1   .... 0 to 5-1=4
	
	
	int length = age.length;  // length
	
	  //    1<=5
	for (int i = 0; i < 5; i++) {
		
		//System.out.println(age[i]);
		
		if(age[i]==45)
		{
			System.out.println(age[i]);
			
		}else {
			System.out.println("45 not ther");
		}
	}
	
	System.out.println("=======================");
	System.out.println(length);
	
	
			System.out.println(age[4]);
	
		
		
	
	
}
}