package BDD_Cucumber.BDD_Cucumber_Framework;

public class StringToInt {

	
	public static void main(String[] args) {
		
	
	
	String number="123";
	
	int age=30;
	
	
	Integer z = Integer.valueOf(number);
	
	System.out.println(z+age);
	
	}
}
