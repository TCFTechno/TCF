package String;

public class Example2 {

	public static void main(String[] args) {

		// == && || != <= >=

		int digitCount = 0;
		int chracCount = 0;
		
		String number="";
		String stringvalues="";
		String name = "3564565SUResh  ";
		for (int i = 0; i < name.length(); i++) {

			if (name.charAt(i) >= '0' && name.charAt(i) <= '9') {
				digitCount++;
				// System.out.println(name.charAt(i));

				number=number+	name.charAt(i);
			} else if ( name.charAt(i) >= 'a' && name.charAt(i) <= 'z' ) {
				chracCount++;
				stringvalues=stringvalues+name.charAt(i);
			}else if (name.charAt(i) >= 'A' && name.charAt(i) <= 'Z' ) {
				
				
			}

		}

		
		System.out.println(number);
		System.out.println(stringvalues);
		System.out.println("chracCount = " + chracCount);
		System.out.println("digitCount = " + digitCount);

	}
}
