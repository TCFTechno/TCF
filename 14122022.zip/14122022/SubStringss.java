package String;

public class SubStringss {

	public static void main(String[] args) {
		
	
	String name="suresh334@gmail.com";
	
	String substring = name.substring(0,9);
	
	
	
	//System.out.println(substring);
	
	
	String names=" ";
	boolean empty = names.isEmpty();
	
	if(empty)
	{
	System.out.println("value is not present");
}else {
	System.out.println("value is  present ");
}
}}