package String;

public class Ex1 {

	public static void main(String[] args) {
		
	//length()
	String name="madhavan";  // 8 length  // index starts 0 to n-1
	int length = name.length();
	System.out.println(length);

	//charAt()
	char charAt = name.charAt(0);
	System.out.println(charAt);
	
	//Equals()
	
	String name1="dd";
	boolean equals = name1.equals(name);
	System.out.println(equals);
	
	//SHORT CUT  -> ctrl+2  L
	
	//Contains()
	String my="my Name suresh";
	String my1="name";
	
	boolean contains = my.contains(my1);
	
	System.out.println("contains"+contains);
	
	//uppercase()
	
	String upper="my name suresh";
	
	String upperCase = upper.toUpperCase();
	System.out.println(upperCase);
	
	//lowercase()
	

	String lower="MY NAME SURESH";
	
	String lowercase = upper.toLowerCase();
	System.out.println(lowercase);
	
	
	//substring
	String sub="m1243adhavan";
	int len = sub.length(); //8
	String substring = sub.substring(4,len);
	System.out.println(substring);
	
	
	
	//indexof()
	
	String io="madhavan";
	int indexOf = io.indexOf('m');
	System.out.println(indexOf);
	
	//split()
	String sp="myname@gmail";
	
	String[] split = sp.split("@");
	for (String string : split) {
		
		System.out.println(string);
		
	}
	
	
	//lastindexof
	
	String saa="madhavan";
	int lastIndexOf = saa.lastIndexOf('n');
	
	System.out.println(lastIndexOf);
	
	
	//isEmpty
	
	
	String isem="";
	boolean empty = isem.isEmpty();
	
	
	System.out.println(empty);
	
	//trim()
	
	String z="           suresh";
	String trim = z.trim();
	
	System.out.println(trim);
	
	
	//compareto()
	
	String o="s";
	String o1="S";
	
	//ASCII   A-Z   65 TO 90
	//a-z  97 to 122
	//0-9  48 to 57
	
	int compareTo = o.compareTo(o1);
	System.out.println(compareTo);
	
	
	
	
	}
}