package String;

public class Basic {

	public static void main(String[] args) {
//immutable // literal String
		
	//it is stored inside the heap memory (String pool or String constant)
	// it will share the same memory if the same value means	
		
		String name1="suresh";
		String name2="suresh";
		
		System.out.println(System.identityHashCode(name1));
		System.out.println(System.identityHashCode(name2));
	
		

		System.out.println(name1);
		System.out.println(name2);

//mutable  //Non Literal String
		
// 	it is stored in the heap memory
//it will create  a new memory everytime even if it is duplicate 
		
		
		String n1=new String ("suresh");
		String n2=new String ("suresh");
		
		System.out.println(n1);
		System.out.println(n2);
	
		System.out.println(System.identityHashCode(n1));
		System.out.println(System.identityHashCode(n2));
		
		
}}