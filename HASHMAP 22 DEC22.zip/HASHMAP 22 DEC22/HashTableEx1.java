package Collections;

import java.util.Hashtable;
import java.util.Map;
import java.util.TreeMap;

public class HashTableEx1 {

	public static void main(String[] args) {

		Map<Integer, String> map = new Hashtable<Integer, String>();

		// put -> insert
		map.put(20, "orange");
		map.put(3, "grapes");
		map.put(111, "ddd"); // entry

		map.put(4, "grapes"); // entry

		System.out.println(map);

	}
}
