package Collections;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class HashMapEx1 {

	public static void main(String[] args) {

		Map<Integer, String> map = new HashMap<Integer, String>();

		// put -> insert
		map.put(1, "apple");   // entry
		map.put(2, "orange");
		map.put(3, "grapes");
		map.put(null, null);
		map.put(4, null);
		map.put(5, "grapes");

		
	
		//entry set - we can print the key and value separateltly   using SET of entry set
		
		Set<Entry<Integer, String>> entrySet = map.entrySet();

		for (Entry<Integer, String> entry : entrySet) {

			{
				
				entry.getKey();
				System.out.println(entry.getKey() + "====  " + entry.getValue());
			}

		}

		// get() -> by passing the key we can get the value

		System.out.println("===================================");

		String string = map.get(2);

		System.out.println(string);
		
	Map<Integer, Integer> map1 = new HashMap<Integer, Integer>();
		
		map1.put(2,55);
		
	Map<Integer, Character> map2 = new HashMap<Integer, Character>();
		
		map2.put(2,'a');
		
		String string2 = map.get(2);
		
		System.out.println(string2);
		
		
		
		
		Integer integer = map1.get(1);
		

		// size() ---> length

		System.out.println("===================================");

		int size = map.size();

		System.out.println(size);


		System.out.println("===================================");

		// containskey() --it will check the key present or not it will retun true or
		// false

		boolean containsKey = map.containsKey(6);

		System.out.println(containsKey);

		System.out.println("===================================");

		// containsvalue()  it will check the vallue presetn or not it will return true or false
		boolean containsValue = map.containsValue(null);

		System.out.println(containsValue);
		
		System.out.println("===================================");

		// clear
		map.clear();
		
		
		Map<Integer, String> map5 = new HashMap<Integer, String>();

		// put -> insert
		map5.put(1, "apple");   // entry
		map5.put(2, "orange");
		map5.put(3, "grapes");
		
		map5.clear();
		
		System.out.println(map5);
	
		System.out.println("===================================");

		// addall()
		
		Map<Integer, String> map7 = new HashMap<Integer, String>();
		Map<Integer, String> map8 = new HashMap<Integer, String>();

		// put -> insert
		map5.put(1, "apple");   // entry
		map5.put(2, "orange");
		map5.put(3, "grapes");
		
		
		map8.putAll(map5);
		
		System.out.println(map8);
		
		System.out.println("===================================");

		//isempty to check null or not
		
		Map<Integer, String> map9 = new HashMap<Integer, String>();
		map9.put(1,"a");
		
		boolean empty = map9.isEmpty();
		
		
		System.out.println(empty);
		Map<Integer, String> map10 = new HashMap<Integer, String>();
		map10.put(1,"a");
		
		System.out.println(map10);
		
		String remove = map10.remove(1);
		
		
		System.out.println(map10);
		System.out.println("===================================");
	// keySet  --  it will print the key value alone
		Map<Integer, String> map20 = new HashMap<Integer, String>();
		
		map20.put(2,"mangao");
		map20.put(1,"banana");
		Set<Integer> keySet = map20.keySet();
	
		System.out.println(keySet);
		

		// value() it will print all the value in hashmap
		System.out.println("===================================");

		Collection<String> values = map.values();

		System.out.println(values);
		
		System.out.println("===================================");
		
		
		
		
	}

}
