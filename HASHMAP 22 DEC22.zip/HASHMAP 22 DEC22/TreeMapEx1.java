package Collections;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.TreeMap;

public class TreeMapEx1 {

	
	
	public static void main(String[] args) {
		
		
		Map<Integer, String> map = new TreeMap<Integer, String>();

		// put -> insert
		map.put(20, "orange");
		map.put(3, "grapes");
		map.put(111, null);   // entry
		
		map.put(null, null);   // entry
		
		System.out.println(map);
		
	}
}
