package Collections;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

public class LinkedHashMapEx1 {

	
	public static void main(String[] args) {
		
		
		Map<Integer, String> map = new LinkedHashMap<Integer, String>();

		// put -> insert
		map.put(2, "orange");
		map.put(3, "grapes");
		map.put(1, "apple");   // entry
		
		map.put(4, null);   // entry
		map.put(0, null);   // entry
		
		System.out.println(map);
		
	}
}
