package Collections;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class CollectionsEx1 {

	public static void main(String[] args) {
		// java 1.8

		// java 11

		// java 19

		ArrayList<Integer> list = new ArrayList<>();

		list.add(1);
		list.add(13);
		list.add(1213);
		list.add(133);

		Integer min = Collections.min(list);

		System.out.println(min);

		Integer max = Collections.max(list);
		System.out.println(max);

		Collections.sort(list);
		System.out.println(list);

		////// array to arraylist

		/// arralist to array

		// int arr[]= {1,3,5,6,10};

		// String array to Arraylist
		String arr[] = { "suresh", "madhavan" };

		ArrayList<String> list2 = new ArrayList<String>();

		Collections.addAll(list2, arr);

		System.out.println(list2);

		// Arraylist to String array

		ArrayList<String> list3 = new ArrayList<String>();

		list3.add("apple");
		list3.add("mango");
		list3.add("orange");

		System.out.println(list3);

		// Object [] a= {"sefd",true,'s',34234234};

		Object[] array = list3.toArray();

		for (Object object : array) {

			System.out.println(object);
		}

		ArrayList<Integer> list4 = new ArrayList<Integer>();

		list4.add(1);
		list3.add(2);
		list3.add(3);

	}
}
