package ExceptionHandling;

public class Ex1 {

	
	
	void add1()
	{
		
		
	}
	

	void add2()
	{
		
		
	}
	
	

	void add3()
	{
		
		
	}
	
	
	
	
	
	public static void main(String[] args) {
		Ex1 e=new Ex1();
		
		e.add1();
		e.add2();
		
		e.add3();
		
		
	}
}
