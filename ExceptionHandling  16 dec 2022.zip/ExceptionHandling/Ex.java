package ExceptionHandling;

public class Ex {

	
	
	
	
	public static void main(String[] args) {
		String name="suresh";

		String name2="suresh"; 

		String name3="suresh"; 

		String name4="suresh"; 



String  s1=new String("suresh");

String  s2=new String("suresh");

System.out.println(System.identityHashCode(s1));

System.out.println(System.identityHashCode(s2));


		System.out.println(System.identityHashCode(name));
	
		System.out.println(System.identityHashCode(name2));
		System.out.println(System.identityHashCode(name3));
		System.out.println(System.identityHashCode(name4));
	
	}
}
