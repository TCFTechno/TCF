package ExceptionHandling;

public class Hellow {

	public static void main(String[] args) {
	
		
		Ex5 e=new Ex5();
		e.add(10, 0);
	}
	
}
