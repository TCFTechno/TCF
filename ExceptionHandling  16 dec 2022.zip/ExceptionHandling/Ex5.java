package ExceptionHandling;

import java.io.IOException;

public class Ex5 {

	void add(int a,int b) throws ArithmeticException {

		//10/0
		
			int c=a/b;
			System.out.println(c);
		
			throw new ArithmeticException();
		

	}

	void sub() throws ArithmeticException {

		System.out.println(10 / 0);

		throw new ArithmeticException();
	}

	public static void main(String[] args) throws Throwable {

		//Ex5 e = new Ex5();

	//	e.add();
	//	e.sub();
	}
}
