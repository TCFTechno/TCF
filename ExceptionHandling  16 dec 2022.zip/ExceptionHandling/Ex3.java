package ExceptionHandling;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;

public class Ex3 {

	static int a = 10;

	public int b = 10;

	public static void main(String[] args) throws Throwable {

		
		// checked Exception
		// compile time exception

		try {
			File file = new File("C:\\Users\\pc2\\Desktop\\New Text Document.xlsx");

			FileInputStream fis = new FileInputStream(file);

		} catch (FileNotFoundException e) {
			System.out.println("file not found");
		}finally {
		
			System.out.println();
			
		}
		

		System.out.println("hello all");
		
		
		
		
		
		
		
		
		
		
		
		
		
		/*
		 * int[] a=new int[5];
		 * 
		 * a[6]=50;
		 */

		/*
		 * String s="abc";
		 * 
		 * int ss = Integer.parseInt(s);
		 * 
		 * int a=10; System.out.println(ss+a);
		 * 
		 */

		// System.out.println(s.length());

		/*
		 * int a=10; int b=0;
		 * 
		 * int c=a/b;
		 * 
		 * System.out.println(c);
		 */
	}
}
